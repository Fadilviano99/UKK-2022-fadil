

<table align="center" width="70%">
	<tr>
		<td width="130px"><img src="icon/icon.png" alt="" width="120px"></td>
		<td>
			<h3>PEDULI DIRI</h3>
			<p> Catatan Perjalanan</p>
			<p>
				<a href="home.php">HOME</a> | 
				<a href="catatan.php">Catatan Perjalanan</a> | 
				<a href="isidata.php">Isi Data</a> |
				<a href="logout.php">Logout</a>
			</p>
	</td>
  </tr>
</table>