<?php
session_start();
 	

if(isset($_POST['daftar']))
{
	$nik = $_POST['nik'];
	$nama = $_POST['nama'];
	$text = $nik .",". $nama . "\n";
	$fp = fopen('config.txt', 'a+');

	if(fwrite($fp, $text)){
		echo '<script>alert("anda berhasil mendaftar");</script>';
	}
}
else if(isset($_POST['masuk']))
{
	$data = file_get_contents("config.txt");
	$contents = explode("\n", $data);

	foreach($contents as $values){
		$login = explode(",", $values);
		$nik = $login[0];
		$nama = $login[1];

		if($nik == $_POST['nik'] && $nama == $_POST['nama']){
			session_start();
			$_SESSION['username'] = $nama;
			header('location: home.php');
		}else{
			echo '<script>alert("Nik atau Nama anda Salah!.");</script>';
		}
	}
}
?>

<html>

<link rel="stylesheet" type="text/css" href="style/login.css">

<form action="" method="POST">
	<center>
	<fieldset style="width: 400px;">
		<legend>Login</legend>
		<table align="center">
			<tr>
				<td><input type="number" name="nik" placeholder="NIK" style="width: 300px; margin-bottom: 10px;" required></td>
			</tr>
			<tr>
				<td><input type="text" name="nama" placeholder="Nama Lengkap" style="width: 300px; margin-bottom: 10px;" required></td>
			</tr>
			<tr class="btn">
				<td><input type="submit" name="daftar"value="Saya Pengguna Baru"></td>
				<td class="btn-masuk"><input type="submit" name="masuk"value="Masuk"></td>
			</tr>
		</table>
		</fieldset>
		</center>
</form>
</html>
